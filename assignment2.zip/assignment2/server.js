/*************************************************************************************
* WEB322 - 2261 Project
* I declare that this assignment is my own work in accordance with the Seneca Academic
* Policy. No part of this assignment has been copied manually or electronically from
* any other source (including web sites) or distributed to other students.
*
* Student Name  : RAKSHITH SINGH
* Student ID    : 131037244
* Student Email : rsrakshith-singh@myseneca.ca
* Course/Section: WEB322/NCC
*
**************************************************************************************/

require("dotenv").config();

const path = require("path");
const express = require("express");
const expressLayouts = require("express-ejs-layouts");
const bodyParser = require("body-parser");
const session = require("express-session");
const mongoose = require("mongoose");

const app = express();

// mongoose connection
mongoose.connect(process.env.MONGODB_CONNECTION_STRING)
.then(() => {
    console.log("Connected to MongoDB");
})
.catch((err) => {
    console.log(`MongoDB connection error: ${err}`);
});

// view engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.set("layout", "layouts/main");
app.locals.layout = "layouts/main";

app.use(expressLayouts);

// middleware
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: false }));

app.use(session({
    secret: process.env.SESSION_SECRET || "mysecretkey",
    resave: false,
    saveUninitialized: false
}));

// make session user available in all views
app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    next();
});

// controllers
const generalController = require("./controllers/general-controller");
const mealkitsController = require("./controllers/mealkits-controller");

app.use("/", generalController);
app.use("/mealkits", mealkitsController);

// 404
app.use((req, res) => {
    res.status(404).render("general/error", {
        title: "Page Not Found",
        statusCode: 404,
        errorMessage: "Page Not Found"
    });
});

// 500
app.use(function (err, req, res, next) {
    console.error(err.stack);
    res.status(500).render("general/error", {
        title: "Server Error",
        statusCode: 500,
        errorMessage: "Something broke!"
    });
});


// *** DO NOT MODIFY THE LINES BELOW ***

// Define a port to listen to requests on.
const HTTP_PORT = process.env.PORT || 8080;

// Call this function after the http server starts listening for requests.
function onHttpStart() {
    console.log("Express http server listening on: " + HTTP_PORT);
}
  
// Listen on port 8080. The default port for http is 80, https is 443. We use 8080 here
// because sometimes port 80 is in use by other applications on the machine
app.listen(HTTP_PORT, onHttpStart);