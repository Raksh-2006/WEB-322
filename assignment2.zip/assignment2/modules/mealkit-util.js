// modules/mealkit-util.js

// local variable 
const mealkits = [
  {
    title: "Butter Chicken with Jeera Rice",
    includes: "Creamy tomato gravy, basmati rice, cucumber salad",
    description: "Restaurant-style butter chicken with fragrant jeera rice.",
    category: "Classic Meals",
    price: 19.99,
    cookingTime: 30,
    servings: 2,
    imageUrl: "/images/butter-chicken.jpg",
    featuredMealKit: true
  },
  {
    title: "Paneer Tikka Wraps",
    includes: "Tandoori paneer, mint chutney, onions, roti wraps",
    description: "Smoky paneer tikka wrapped with fresh toppings.",
    category: "Classic Meals",
    price: 17.99,
    cookingTime: 25,
    servings: 2,
    imageUrl: "/images/paneer-wraps.jpg",
    featuredMealKit: true
  },
  {
    title: "Chicken Biryani Bowl",
    includes: "Spiced chicken, basmati rice, fried onions, raita",
    description: "A bold biryani-style bowl with cooling raita.",
    category: "Classic Meals",
    price: 21.99,
    cookingTime: 35,
    servings: 2,
    imageUrl: "/images/chicken-biryani.jpg",
    featuredMealKit: false
  },
  {
    title: "Hakka Noodles with Chilli Chicken",
    includes: "Stir-fried noodles, peppers, chilli chicken, sesame",
    description: "Indo-Chinese comfort: spicy, savoury, and fast.",
    category: "Classic Meals",
    price: 20.99,
    cookingTime: 25,
    servings: 2,
    imageUrl: "/images/hakka-noodles.jpg",
    featuredMealKit: false
  },

  // Second 
  {
    title: "Vegan Dal Tadka with Rice",
    includes: "Yellow lentils, tadka spices, basmati rice, lemon",
    description: "Simple, protein-rich dal finished with a fragrant tadka.",
    category: "Vegan Meals",
    price: 16.99,
    cookingTime: 25,
    servings: 2,
    imageUrl: "/images/dal-tadka.jpg",
    featuredMealKit: true
  },
  {
    title: "Chana Masala with Roti",
    includes: "Chickpea curry, roti, pickled onions",
    description: "A hearty chickpea curry with warm roti on the side.",
    category: "Vegan Meals",
    price: 15.99,
    cookingTime: 25,
    servings: 2,
    imageUrl: "/images/chana-masala.jpg",
    featuredMealKit: false
  }
];

// Returns ALL meal kits
function getAllMealKits() {
  return mealkits;
}

// Returns ONLY featured meal kits from the array passed in
function getFeaturedMealKits(mealkits) {
  return mealkits.filter(mk => mk.featuredMealKit === true);
}

// Groups meal kits by category from the array passed in
function getMealKitsByCategory(mealkits) {
  const grouped = [];

  mealkits.forEach(mk => {
    const existing = grouped.find(g => g.categoryName === mk.category);

    if (existing) {
      existing.mealKits.push(mk);
    } else {
      grouped.push({
        categoryName: mk.category,
        mealKits: [mk]
      });
    }
  });

  return grouped;
}

module.exports = {
    getAllMealKits,
    getFeaturedMealKits,
    getMealKitsByCategory
};