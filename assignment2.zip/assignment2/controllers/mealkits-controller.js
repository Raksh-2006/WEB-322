const express = require("express");
const router = express.Router();
const mealKitUtil = require("../modules/mealkit-util");

router.get("/", (req, res) => {
    const groupedMealKits = mealKitUtil.getMealKitsByCategory(mealKitUtil.getAllMealKits());

    res.render("mealkits/on-the-menu", {
        title: "On The Menu",
        groupedMealKits
    });
});

router.get("/list", (req, res) => {
    if (!req.session.user) {
        return res.status(401).render("general/error", {
            title: "Unauthorized",
            statusCode: 401,
            errorMessage: "You are not authorized to view this page"
        });
    }

    if (req.session.user.role !== "clerk") {
        return res.status(401).render("general/error", {
            title: "Unauthorized",
            statusCode: 401,
            errorMessage: "You are not authorized to view this page"
        });
    }

    res.render("mealkits/list", {
        title: "Meal Kits List"
    });
});

module.exports = router;