const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const userModel = require("../models/userModel");
const mealKitUtil = require("../modules/mealkit-util");

router.get("/", (req, res) => {
    const allMealKits = mealKitUtil.getAllMealKits();
    const featured = mealKitUtil.getFeaturedMealKits(allMealKits);

    res.render("general/home", {
        title: "Home",
        featured
    });
});

router.get("/sign-up", (req, res) => {
    res.render("general/sign-up", {
        title: "Sign Up",
        values: {},
        errors: {}
    });
});

router.post("/sign-up", (req, res) => {
    const { firstName, lastName, email, password } = req.body;

    let errors = {};
    let values = {
        firstName,
        lastName,
        email,
        password
    };

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).{8,12}$/;

    if (!firstName || firstName.trim() === "") {
        errors.firstName = "First name is required.";
    }

    if (!lastName || lastName.trim() === "") {
        errors.lastName = "Last name is required.";
    }

    if (!email || email.trim() === "") {
        errors.email = "Email is required.";
    } else if (!emailRegex.test(email)) {
        errors.email = "Please enter a valid email address.";
    }

    if (!password || password.trim() === "") {
        errors.password = "Password is required.";
    } else if (!passwordRegex.test(password)) {
        errors.password = "Password must be 8 to 12 characters and include uppercase, lowercase, and a number.";
    }

    if (Object.keys(errors).length > 0) {
        return res.render("general/sign-up", {
            title: "Sign Up",
            errors,
            values
        });
    }

    userModel.findOne({ email: email.trim() })
        .then(existingUser => {
            if (existingUser) {
                return res.render("general/sign-up", {
                    title: "Sign Up",
                    errors: { email: "Email is already registered." },
                    values
                });
            }

            return bcrypt.hash(password, 10)
                .then(hashedPassword => {
                    const newUser = new userModel({
                        firstName: firstName.trim(),
                        lastName: lastName.trim(),
                        email: email.trim(),
                        password: hashedPassword
                    });

                    return newUser.save();
                })
                .then(() => {
                    res.render("general/welcome", {
                        title: "Welcome"
                    });
                });
        })
        .catch(err => {
            console.log(err);
            res.status(500).render("general/error", {
                title: "Server Error",
                statusCode: 500,
                errorMessage: "Could not create account."
            });
        });
});

router.get("/log-in", (req, res) => {
    res.render("general/log-in", {
        title: "Log In",
        values: { email: "", role: "customer" },
        errors: {}
    });
});

router.post("/log-in", (req, res) => {
    const { email, password, role } = req.body;

    let errors = {};
    let values = {
        email,
        role
    };

    if (!email || email.trim() === "") {
        errors.email = "Email is required.";
    }

    if (!password || password.trim() === "") {
        errors.password = "Password is required.";
    }

    if (!role) {
        errors.role = "Role is required.";
    }

    if (Object.keys(errors).length > 0) {
        return res.render("general/log-in", {
            title: "Log In",
            errors,
            values
        });
    }

    userModel.findOne({ email: email.trim() })
        .then(user => {
            if (!user) {
                return res.render("general/log-in", {
                    title: "Log In",
                    errors: { email: "No account found with this email." },
                    values
                });
            }

            return bcrypt.compare(password, user.password)
                .then(isMatch => {
                    if (!isMatch) {
                        return res.render("general/log-in", {
                            title: "Log In",
                            errors: { password: "Incorrect password." },
                            values
                        });
                    }

                    req.session.user = {
                        email: user.email,
                        role: role
                    };

                    if (role === "customer") {
                        return res.redirect("/cart");
                    } else {
                        return res.redirect("/mealkits/list");
                    }
                });
        })
        .catch(err => {
            console.log(err);
            res.status(500).render("general/error", {
                title: "Server Error",
                statusCode: 500,
                errorMessage: "Login failed."
            });
        });
});

router.get("/welcome", (req, res) => {
    res.render("general/welcome", {
        title: "Welcome"
    });
});

router.get("/cart", (req, res) => {
    if (!req.session.user || req.session.user.role !== "customer") {
        return res.status(401).render("general/error", {
            title: "Unauthorized",
            statusCode: 401,
            errorMessage: "You are not authorized to view this page"
        });
    }

    res.render("general/cart", {
        title: "Shopping Cart"
    });
});

router.get("/logout", (req, res) => {
    req.session.destroy(() => {
        res.redirect("/log-in");
    });
});

module.exports = router;